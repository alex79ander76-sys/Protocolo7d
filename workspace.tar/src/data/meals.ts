export const FOOD_IMG = {
  plato: "https://image.qwenlm.ai/generated-images/b276dc13-d6ef-4767-a68f-f41b8d4f0102/_result.png",
  desayuno: "https://image.qwenlm.ai/generated-images/f94dc593-b1f8-4192-b190-5dd700bd1d83/_result.png",
  despensa: "https://image.qwenlm.ai/generated-images/b116b6cc-1f8b-4ea4-8da6-c5b6773434e0/_result.png",
};

export type MealSlot = "desayuno" | "almuerzo" | "merienda" | "cena";

export type MealOption = {
  name: string;
  desc: string;
  tag: string;
  img: string;
  ingredients?: string[];
  steps?: string[];
};

export const SLOT_LABEL: Record<MealSlot, string> = {
  desayuno: "Desayuno",
  almuerzo: "Almuerzo",
  merienda: "Merienda",
  cena: "Cena",
};

const u = (id: string) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=520&h=300&q=65`;

export const MEAL_POOLS: Record<MealSlot, MealOption[]> = {
  desayuno: [
    { name: "Yogur griego + avena + nueces", desc: "Con arándanos y un hilo de miel.", tag: "10 min", img: u("photo-1490645935967-10de6ba17061"), ingredients: ["150g yogur griego natural", "30g avena en hojuelas", "1 puñado de nueces", "1 puñado de arándanos", "1 cucharadita de miel"], steps: ["Pon el yogur griego en un bol", "Añade la avena y mezcla", "Coloca las nueces y arándanos por encima", "Termina con un hilo de miel"] },
    { name: "Tostada + aguacate + huevo", desc: "Pan integral, huevo revuelto suave.", tag: "Proteína", img: u("photo-1525351484163-7529414344d8"), ingredients: ["1 rebanada de pan integral", "1/2 aguacate maduro", "1 huevo", "Sal y pimienta", "1 cucharadita de aceite de oliva"], steps: ["Tuesta el pan integral", "Machaca el aguacate con un tenedor y salpimienta", "Bate el huevo y cocínalo en la sartén con aceite a fuego medio, removiendo constantemente", "Extiende el aguacate sobre la tostada y corona con el huevo revuelto"] },
    { name: "Porridge de avena y manzana", desc: "Con canela y almendras picadas.", tag: "Fibra", img: u("photo-1504754524776-8f4f37790ca0"), ingredients: ["40g avena", "200ml leche o bebida vegetal", "1 manzana", "1 cucharadita de canela", "1 puñado de almendras picadas"], steps: ["Calienta la leche en un cazo", "Añade la avena y cocina 5 minutos removiendo", "Corta la manzana en daditos", "Sirve el porridge con la manzana, canela y almendras por encima"] },
    { name: "Batido de plátano y cacahuete", desc: "Leche, plátano, avena y crema de cacahuete.", tag: "Sin cocinar", img: u("photo-1553530666-ba11a7da3888"), ingredients: ["1 plátano maduro", "200ml leche o bebida de avena", "30g avena", "1 cucharada de crema de cacahuete"], steps: ["Pela el plátano y córtalo en rodajas", "Pon todos los ingredientes en la batidora", "Tritura hasta obtener una textura suave", "Sirve inmediatamente"] },
    { name: "Tostada + queso fresco + tomate", desc: "Con aceite de oliva virgen extra.", tag: "Mediterráneo", img: u("photo-1541519227354-08fa5d50c44d"), ingredients: ["1 rebanada de pan integral", "50g queso fresco", "1 tomate maduro", "Aceite de oliva virgen extra", "Sal y orégano"], steps: ["Tuesta el pan integral", "Corta el tomate en rodajas finas", "Extiende el queso fresco sobre la tostada", "Coloca las rodajas de tomate encima", "Añade un chorrito de aceite, sal y orégano"] },
    { name: "Huevos + espinacas + pan", desc: "Revuelto suave con pan integral.", tag: "Proteína", img: u("photo-1482049016688-2d3e1b311543"), ingredients: ["2 huevos", "1 puñado de espinacas frescas", "1 rebanada de pan integral", "1 cucharadita de aceite de oliva", "Sal y pimienta"], steps: ["Calienta el aceite en una sartén", "Añade las espinacas y saltea 1 minuto", "Bate los huevos y viértelos en la sartén", "Remueve suavemente hasta que cuajen pero queden cremosos", "Salpimienta y sirve con el pan tostado"] },
    { name: "Yogur + chía + kiwi", desc: "Con un puñado de almendras.", tag: "5 min", img: u("photo-1484980972926-edee96e0960d"), ingredients: ["150g yogur natural", "1 cucharada de semillas de chía", "1 kiwi", "1 puñado de almendras"], steps: ["Pon el yogur en un bol", "Añade las semillas de chía y mezcla", "Pela el kiwi y córtalo en rodajas", "Coloca el kiwi y las almendras por encima"] },
    { name: "Tortilla francesa + fruta", desc: "De dos huevos, con pan y una pieza de fruta.", tag: "Clásico", img: u("photo-1543353071-873f17a7a088"), ingredients: ["2 huevos", "1 rebanada de pan integral", "1 pieza de fruta (pera, manzana o naranja)", "Sal", "1 cucharadita de aceite de oliva"], steps: ["Bate los huevos con una pizca de sal", "Calienta el aceite en una sartén antiadherente", "Vierte los huevos y cocina a fuego medio", "Cuando empiece a cuajar, dobla por la mitad", "Sirve con pan tostado y la fruta"] },
    { name: "Avena nocturna con fresas", desc: "Preparada la noche anterior con yogur.", tag: "Lista al despertar", img: u("photo-1547573854-74d2a71d0826"), ingredients: ["40g avena", "100ml leche", "100g yogur natural", "1 puñado de fresas", "1 cucharadita de miel (opcional)"], steps: ["La noche anterior, mezcla la avena con la leche en un tarro", "Añade el yogur y mezcla bien", "Tapa y refrigera toda la noche", "Por la mañana, corta las fresas y colócalas encima", "Añade miel si lo deseas"] },
    { name: "Requesón + miel + nueces", desc: "Con una rebanada de pan integral.", tag: "Proteína", img: u("photo-1488477181946-6428a0291777"), ingredients: ["100g requesón", "1 cucharadita de miel", "3-4 nueces", "1 rebanada de pan integral"], steps: ["Pon el requesón en un bol", "Añade la miel por encima", "Tritura las nueces y espolvoréalas", "Tuesta el pan y sirve junto al requesón"] },
  ],
  almuerzo: [
    { name: "Pollo + arroz + ensalada", desc: "Pechuga a la plancha, arroz blanco y hoja verde.", tag: "Base", img: u("photo-1546069901-ba9599a7e63c"), ingredients: ["150g pechuga de pollo", "60g arroz blanco", "Lechuga, tomate y pepino", "Aceite de oliva, sal y limón"], steps: ["Cuece el arroz en agua con sal durante 15 minutos", "Sazona la pechuga con sal y pimienta", "Cocina a la plancha 5-6 minutos por lado", "Prepara la ensalada con lechuga, tomate y pepino", "Aliña con aceite, sal y limón"] },
    { name: "Lentejas con verduras", desc: "Guiso suave de cuchara, sin embutido.", tag: "Legumbre", img: u("photo-1547592166-23ac45744acd"), ingredients: ["200g lentejas", "1 zanahoria", "1 patata", "1 cebolla", "2 dientes de ajo", "1 hoja de laurel", "Aceite de oliva y sal"], steps: ["Pica la cebolla, zanahoria y patata en dados", "Sofríe la cebolla y el ajo con aceite", "Añade las verduras y sofríe 2 minutos", "Incorpora las lentejas lavadas y el laurel", "Cubre con agua y cocina 30-35 minutos", "Ajusta la sal al final"] },
    { name: "Salmón + patata + brócoli", desc: "Al horno, con limón y AOVE.", tag: "Omega-3", img: u("photo-1467003909585-2f8a72700288"), ingredients: ["150g salmón", "1 patata mediana", "150g brócoli", "1 limón", "Aceite de oliva y sal"], steps: ["Precalienta el horno a 200°C", "Corta la patata en rodajas y el brócoli en ramilletes", "Coloca en una bandeja con aceite y sal", "Hornea 15 minutos", "Añade el salmón y hornea 10 minutos más", "Sirve con un chorrito de limón"] },
    { name: "Garbanzos salteados + huevo", desc: "Con espinacas y pimentón.", tag: "Vegetal", img: u("photo-1512058564366-18510be2db19"), ingredients: ["200g garbanzos cocidos", "1 puñado de espinacas", "1 huevo", "1 diente de ajo", "Pimentón dulce", "Aceite de oliva y sal"], steps: ["Sofríe el ajo laminado con aceite", "Añade las espinacas y saltea 1 minuto", "Incorpora los garbanzos y el pimentón", "Saltea 3-4 minutos", "Fríe el huevo aparte", "Sirve los garbanzos con el huevo encima"] },
    { name: "Pavo + quinoa + verduras asadas", desc: "Calabacín, pimiento y cebolla.", tag: "Ligero", img: u("photo-1512621776951-a57141f2eefd"), ingredients: ["150g pechuga de pavo", "60g quinoa", "1 calabacín", "1 pimiento", "1/2 cebolla", "Aceite de oliva y sal"], steps: ["Cocina la quinoa según instrucciones del paquete", "Corta las verduras en trozos y ásallas con aceite", "Sazona el pavo y cocínalo a la plancha", "Sirve la quinoa con las verduras y el pavo"] },
    { name: "Pasta integral + atún + tomate", desc: "Con albahaca y un poco de queso.", tag: "Rápido", img: u("photo-1473093295043-cdd812d0e601"), ingredients: ["80g pasta integral", "1 lata de atún al natural", "200g tomate triturado", "Albahaca fresca", "Queso parmesano rallado", "Aceite de oliva y sal"], steps: ["Cuece la pasta según instrucciones", "Calienta el tomate con aceite y sal", "Añade el atún escurrido", "Escurre la pasta y mézclala con la salsa", "Sirve con albahaca y queso rallado"] },
    { name: "Merluza + judías verdes", desc: "Con patata cocida y AOVE en crudo.", tag: "Pescado", img: u("photo-1519708227418-c8fd9a32b7a2"), ingredients: ["150g merluza", "200g judías verdes", "1 patata", "Aceite de oliva virgen extra", "Sal"], steps: ["Cuece la patata con piel 20 minutos", "Cuece las judías verdes 8-10 minutos", "Cocina la merluza a la plancha 3-4 minutos por lado", "Sirve con la patata cortada y las judías", "Añade un chorrito de AOVE en crudo"] },
    { name: "Ensalada de legumbres", desc: "Con huevo duro, tomate y cebolla.", tag: "Sin fuego", img: u("photo-1540189549336-e6e99c3679fe"), ingredients: ["200g legumbres cocidas (garbanzos o lentejas)", "2 huevos duros", "1 tomate", "1/2 cebolla", "Aceite de oliva, vinagre y sal"], steps: ["Cuece los huevos 10 minutos y pélalos", "Corta el tomate y la cebolla en dados", "Mezcla las legumbres con las verduras", "Añade los huevos cortados en cuartos", "Aliña con aceite, vinagre y sal"] },
    { name: "Ternera magra + boniato", desc: "Con pimientos asados.", tag: "Hierro", img: u("photo-1544025162-d76694265947"), ingredients: ["150g ternera magra", "1 boniato mediano", "1 pimiento rojo", "Aceite de oliva y sal"], steps: ["Precalienta el horno a 200°C", "Corta el boniato en rodajas y el pimiento en tiras", "Ásalos con aceite 20 minutos", "Sazona la ternera y cocínala a la plancha", "Sirve con las verduras asadas"] },
    { name: "Arroz con verduras y pollo", desc: "Estilo arroz a la cubana, versión suave.", tag: "Batch cooking", img: u("photo-1504674900247-0877df9cc836"), ingredients: ["80g arroz", "100g pollo en tiras", "1 zanahoria", "1 calabacín", "1/2 cebolla", "Aceite de oliva y sal"], steps: ["Cocina el arroz y reserva", "Sofríe la cebolla, zanahoria y calabacín", "Añade el pollo y cocina 5 minutos", "Mezcla todo con el arroz", "Ajusta la sal y sirve"] },
    { name: "Crema de calabaza + tortilla", desc: "Con pan integral tostado.", tag: "Cuchara", img: u("photo-1476718406336-bb5a9690ee2a"), ingredients: ["300g calabaza", "1 cebolla", "2 huevos", "1 rebanada de pan integral", "Aceite de oliva y sal"], steps: ["Sofríe la cebolla con aceite", "Añade la calabaza en dados y cubre con agua", "Cocina 20 minutos y tritura", "Bate los huevos y haz una tortilla", "Sirve la crema con la tortilla y pan tostado"] },
    { name: "Wrap integral + hummus", desc: "Con pollo, zanahoria y espinaca.", tag: "Portable", img: u("photo-1476224203421-9ac39bcb3327"), ingredients: ["1 tortilla integral", "2 cucharadas de hummus", "100g pollo cocido", "1 zanahoria rallada", "Espinacas frescas"], steps: ["Extiende el hummus sobre la tortilla", "Coloca las espinacas", "Añade el pollo en tiras", "Espolvorea la zanahoria rallada", "Enrolla firmemente y corta por la mitad"] },
  ],
  cena: [
    { name: "Tortilla de verduras + ensalada", desc: "Con calabacín y cebolla, cuajada suave.", tag: "Ligera", img: u("photo-1543353071-873f17a7a088"), ingredients: ["3 huevos", "1 calabacín", "1/2 cebolla", "Lechuga y tomate", "Aceite de oliva y sal"], steps: ["Pica el calabacín y la cebolla", "Sofríe las verduras 5 minutos", "Bate los huevos y mézclalos con las verduras", "Cuaja la tortilla en la sartén", "Prepara una ensalada simple para acompañar"] },
    { name: "Pescado blanco + verduras al vapor", desc: "Merluza o dorada con AOVE en crudo.", tag: "Temprana", img: u("photo-1432139555190-58524dae6a55"), ingredients: ["150g pescado blanco", "200g verduras variadas (brócoli, zanahoria, judías)", "Aceite de oliva virgen extra", "Sal"], steps: ["Cocina las verduras al vapor 8-10 minutos", "Sazona el pescado y cocínalo a la plancha o al vapor", "Sirve el pescado con las verduras", "Añade un chorrito de AOVE en crudo"] },
    { name: "Sopa de verduras + huevo", desc: "Escalfado dentro, bien caliente.", tag: "Cuchara", img: u("photo-1547592166-23ac45744acd"), ingredients: ["1 zanahoria", "1 patata", "1 puerro", "1 calabacín", "1 huevo", "Aceite de oliva y sal"], steps: ["Pica todas las verduras", "Sofríe el puerro y añade el resto de verduras", "Cubre con agua y cocina 20 minutos", "Tritura o deja en trozos según prefieras", "Casca el huevo en la sopa caliente y deja que se cocine"] },
    { name: "Revuelto de setas + pan", desc: "Con ajo y perejil, pan integral.", tag: "10 min", img: u("photo-1555949258-eb67b1ef0ceb"), ingredients: ["2 huevos", "150g setas variadas", "1 diente de ajo", "Perejil fresco", "1 rebanada de pan integral", "Aceite de oliva y sal"], steps: ["Lamina las setas y pica el ajo", "Sofríe el ajo y añade las setas", "Cocina 5 minutos hasta que estén doradas", "Bate los huevos y añádelos a la sartén", "Remueve hasta que cuajen suavemente", "Añade perejil picado y sirve con pan tostado"] },
    { name: "Ensalada completa + atún", desc: "Con huevo, tomate, aceitunas y maíz.", tag: "Sin fuego", img: u("photo-1546069901-ba9599a7e63c"), ingredients: ["Lechuga variada", "1 tomate", "1 lata de atún", "1 huevo duro", "Aceitunas", "Maíz", "Aceite de oliva, vinagre y sal"], steps: ["Lava y corta la lechuga", "Corta el tomate en dados", "Cuece el huevo 10 minutos y pélalo", "Mezcla todo con el atún, aceitunas y maíz", "Aliña con aceite, vinagre y sal"] },
    { name: "Pollo + puré de coliflor", desc: "Cremoso, con nuez moscada.", tag: "Baja en carbos", img: u("photo-1414235077428-338989a2e8c0"), ingredients: ["150g pechuga de pollo", "1 coliflor mediana", "Nuez moscada", "Aceite de oliva y sal"], steps: ["Cuece la coliflor 15 minutos", "Tritura con un poco de aceite y nuez moscada", "Sazona el pollo y cocínalo a la plancha", "Sirve el pollo con el puré de coliflor"] },
    { name: "Salmón + espárragos", desc: "A la plancha, con limón.", tag: "Omega-3", img: u("photo-1519708227418-c8fd9a32b7a2"), ingredients: ["150g salmón", "200g espárragos", "1 limón", "Aceite de oliva y sal"], steps: ["Lava los espárragos y córtalos", "Cocínalos a la plancha 5-6 minutos", "Sazona el salmón y cocínalo 3-4 minutos por lado", "Sirve con un chorrito de limón"] },
    { name: "Crema de verduras + queso fresco", desc: "Con pipas por encima.", tag: "Cuchara", img: u("photo-1476224203421-9ac39bcb3327"), ingredients: ["1 calabacín", "1 zanahoria", "1 patata", "1 cebolla", "50g queso fresco", "Pipas de calabaza", "Aceite de oliva y sal"], steps: ["Pica las verduras y sofríe la cebolla", "Añade el resto de verduras y cubre con agua", "Cocina 20 minutos y tritura", "Sirve con dados de queso fresco y pipas por encima"] },
    { name: "Garbanzos + espinacas", desc: "Salteados con ajo y comino.", tag: "Vegetal", img: u("photo-1512621776951-a57141f2eefd"), ingredients: ["200g garbanzos cocidos", "200g espinacas", "2 dientes de ajo", "Comino", "Aceite de oliva y sal"], steps: ["Sofríe el ajo laminado con aceite", "Añade las espinacas y saltea hasta que se reduzcan", "Incorpora los garbanzos y el comino", "Saltea 3-4 minutos y sirve"] },
    { name: "Pavo + calabacín salteado", desc: "Filetes finos con hierbas.", tag: "Ligera", img: u("photo-1504674900247-0877df9cc836"), ingredients: ["150g pechuga de pavo", "1 calabacín", "Hierbas provenzales", "Aceite de oliva y sal"], steps: ["Corta el calabacín en rodajas", "Saltea con aceite 5 minutos", "Sazona el pavo con hierbas", "Cocina a la plancha 3-4 minutos por lado", "Sirve juntos"] },
    { name: "Merluza en papillote", desc: "Con tomate cherry y albahaca.", tag: "Horno", img: u("photo-1467003909585-2f8a72700288"), ingredients: ["150g merluza", "Tomates cherry", "Albahaca fresca", "Aceite de oliva y sal"], steps: ["Precalienta el horno a 180°C", "Coloca el pescado en papel de horno", "Añade tomates cherry cortados y albahaca", "Cierra el papillote y hornea 15 minutos", "Abre con cuidado y sirve"] },
    { name: "Ensalada templada de lentejas", desc: "Con verduras pochadas y AOVE.", tag: "Fibra", img: u("photo-1540189549336-e6e99c3679fe"), ingredients: ["200g lentejas cocidas", "1 pimiento", "1 cebolla", "1 tomate", "Aceite de oliva virgen extra y sal"], steps: ["Pocha la cebolla y el pimiento", "Añade las lentejas y calienta", "Corta el tomate y mézclalo", "Sirve templado con un buen chorro de AOVE"] },
  ],
  merienda: [
    { name: "Fruta + almendras", desc: "Una pieza de temporada y un puñado crudo.", tag: "Clásico", img: u("photo-1568702846914-96b305d2aaeb"), ingredients: ["1 pieza de fruta de temporada", "1 puñado de almendras crudas (15-20)"], steps: ["Lava la fruta", "Córtala si lo prefieres", "Acompaña con las almendras"] },
    { name: "Yogur natural + semillas", desc: "Con calabaza o girasol.", tag: "5 min", img: u("photo-1488477181946-6428a0291777"), ingredients: ["150g yogur natural", "1 cucharada de semillas de calabaza o girasol"], steps: ["Pon el yogur en un bol", "Espolvorea las semillas por encima", "Mezcla y disfruta"] },
    { name: "Tostada + queso fresco", desc: "Con rodajas de tomate o pepino.", tag: "Salado", img: u("photo-1528735602780-2552fd46c7af"), ingredients: ["1 rebanada de pan integral", "50g queso fresco", "1 tomate o 1/2 pepino", "Aceite de oliva y sal"], steps: ["Tuesta el pan", "Extiende el queso fresco", "Corta el tomate o pepino en rodajas finas", "Colócalas encima", "Añade un chorrito de aceite y sal"] },
    { name: "Huevo duro + zanahoria", desc: "Palitos crujientes con limón.", tag: "Proteína", img: u("photo-1482049016688-2d3e1b311543"), ingredients: ["1 huevo", "1 zanahoria", "Limón", "Sal"], steps: ["Cuece el huevo 10 minutos", "Pela y corta en cuartos", "Corta la zanahoria en palitos", "Acompaña con un chorrito de limón y sal"] },
    { name: "Batido de plátano", desc: "Con leche o bebida de avena.", tag: "Líquido", img: u("photo-1553530666-ba11a7da3888"), ingredients: ["1 plátano maduro", "200ml leche o bebida de avena"], steps: ["Pela el plátano", "Pon todos los ingredientes en la batidora", "Tritura hasta obtener una textura suave", "Sirve inmediatamente"] },
    { name: "Requesón + miel", desc: "Con dos nueces partidas.", tag: "Dulce sano", img: u("photo-1505576399279-565b52d4ac71"), ingredients: ["100g requesón", "1 cucharadita de miel", "2 nueces"], steps: ["Pon el requesón en un bol", "Añade la miel por encima", "Tritura las nueces y espolvoréalas"] },
    { name: "Fruta + queso fresco", desc: "Peras o manzana con dados de queso.", tag: "Mixto", img: u("photo-1490474418585-ba9bad8fd0ea"), ingredients: ["1 pera o manzana", "50g queso fresco en dados"], steps: ["Lava la fruta", "Córtala en dados", "Mezcla con los dados de queso fresco"] },
    { name: "Nueces + chocolate 85%", desc: "Un puñado y dos onzas, sin culpa.", tag: "80/20", img: u("photo-1511381939415-e44015466834"), ingredients: ["1 puñado de nueces (20-25g)", "2 onzas de chocolate 85% cacao"], steps: ["Pon las nueces en un bol", "Parte el chocolate en trozos", "Disfruta como snack"] },
  ],
};

export const DAYS = [
  { num: "01", name: "Lunes", short: "LUN" },
  { num: "02", name: "Martes", short: "MAR" },
  { num: "03", name: "Miércoles", short: "MIÉ" },
  { num: "04", name: "Jueves", short: "JUE" },
  { num: "05", name: "Viernes", short: "VIE" },
  { num: "06", name: "Sábado", short: "SÁB" },
  { num: "07", name: "Domingo", short: "DOM" },
];

export const SLOTS: MealSlot[] = ["desayuno", "almuerzo", "merienda", "cena"];

const DAY_STEP: Record<MealSlot, number> = { desayuno: 1, almuerzo: 3, merienda: 2, cena: 5 };
const WEEK_STEP: Record<MealSlot, number> = { desayuno: 3, almuerzo: 5, merienda: 7, cena: 4 };

export function pickMeal(slot: MealSlot, dayIdx: number, week: number, swaps: number): MealOption {
  const pool = MEAL_POOLS[slot];
  const base = (dayIdx * DAY_STEP[slot] + week * WEEK_STEP[slot] + swaps) % pool.length;
  const idx = ((base % pool.length) + pool.length) % pool.length;
  return pool[idx];
}

export const TOTAL_MENU_OPTIONS = SLOTS.reduce((acc, s) => acc + MEAL_POOLS[s].length, 0);

export const HOUSE_RULES = [
  { title: "Proteína en cada comida", desc: "Después de los 40 el músculo se defiende peor: reparte 25-30 g por comida en vez de cargarlo todo en la cena." },
  { title: "Mitad del plato, verdura", desc: "Volumen, fibra y saciedad sin contar una sola caloría. El plato manda, la báscula no." },
  { title: "Carbohidrato cuando lo usas", desc: "Arroz, patata o legumbre alrededor de tu sesión o de tu día activo. No es el enemigo: es gasolina." },
  { title: "Agua antes que hambre", desc: "Mucha «hambre» de media tarde es en realidad sed. Vaso grande, diez minutos de espera y decides." },
  { title: "80/20, siempre", desc: "Ocho de cada diez comidas, al plan. Las otras dos, vida. Eso es costumbre; lo otro, dieta." },
];

export const PLATE_SEGMENTS = [
  { id: "verdura", label: "Verdura", pct: "50%", color: "#3e7c4f", desc: "La mitad del plato, siempre. Hoja verde, brócoli, tomate, calabacín… lo que haya de temporada." },
  { id: "proteina", label: "Proteína", pct: "25%", color: "#2e6bff", desc: "Huevo, pescado, pollo, legumbre o yogur griego. El ladrillo del músculo a partir de los 40." },
  { id: "carbo", label: "Carbohidrato", pct: "25%", color: "#f0ae1c", desc: "Arroz, patata, avena o legumbre. Gasolina alrededor de tu actividad, sin miedo y sin exceso." },
];
