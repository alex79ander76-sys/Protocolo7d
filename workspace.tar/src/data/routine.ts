const IMG = {
  calentamiento: "https://image.qwenlm.ai/generated-images/ad1dcfc4-2db8-4ea0-adbf-cd5da5b9e1f9/_result.png",
  sentadilla: "https://image.qwenlm.ai/generated-images/96f31b33-4db2-47e1-84c0-b1396c5f123f/_result.png",
  flexiones: "https://image.qwenlm.ai/generated-images/4ff3d249-bfc8-40ed-9eb3-f6bc23db2ec1/_result.png",
  plancha: "https://image.qwenlm.ai/generated-images/418c2bf0-5afe-4d8a-892f-7dd58bc6b720/_result.png",
  remo: "https://image.qwenlm.ai/generated-images/1a3f83a2-7986-416e-a790-c4879cc8eb0d/_result.png",
  circuito: "https://image.qwenlm.ai/generated-images/90a6005b-6e44-4cbb-85e8-522e8bdcebb5/_result.png",
  estiramiento: "https://image.qwenlm.ai/generated-images/d066822a-b795-471d-bc50-70063aff8150/_result.png",
  cuadriceps: "https://image.qwenlm.ai/generated-images/e02c37e7-7dcc-4919-b421-8892aa87dda0/_result.png",
};
export { IMG };

export const SAMPLE_VIDEO = "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4";

export const VIDEOS = {
  calentamiento: "https://www.youtube.com/watch?v=g_tea8ptk5A",
  trote: "https://www.youtube.com/watch?v=7xhNDjvQ2Kw",
  zancada: "https://www.youtube.com/watch?v=QOVaHwm-Q6U",
  flexionEscapular: "https://www.youtube.com/watch?v=5H_3LqQ9Z0I",
  sentadilla: "https://www.youtube.com/watch?v=aclHkVaku9U",
  flexiones: "https://www.youtube.com/watch?v=IODxDxX7oi4",
  plancha: "https://www.youtube.com/watch?v=pSHjTRCQxIw",
  remada: "https://www.youtube.com/watch?v=ro8r8LeKq0U",
  cuerdas: "https://www.youtube.com/watch?v=EOCqgKp8JQw",
  burpees: "https://www.youtube.com/watch?v=TU8QYVW0gDU",
  goblet: "https://www.youtube.com/watch?v=MeIiIdhvXT4",
  estiramientoIsquios: "https://www.youtube.com/watch?v=VjtxqF9a1aI",
  estiramientoPsoas: "https://www.youtube.com/watch?v=7kPfD1nZcZw",
  aperturaToracica: "https://www.youtube.com/watch?v=VhU1p8f9Z8I",
  respiracion: "https://www.youtube.com/watch?v=DbDqXtCqYgE",
};

export type Exercise = {
  id: string;
  name: string;
  scheme: string;
  rest?: string;
  cues?: string[];
  image?: string;
  imageLabel?: string;
  defaultVideo?: string;
  tag?: string;
};

export type Block = {
  id: string;
  num: string;
  title: string;
  kicker: string;
  duration: string;
  focus: string;
  dark?: boolean;
  image: string;
  imageCaption: string;
  accent: "ember" | "cobalt" | "mustard";
  exercises: Exercise[];
  note?: string;
};

export const BLOCKS: Block[] = [
  {
    id: "calentamiento",
    num: "01",
    title: "Calentamiento",
    kicker: "Activación y movilidad",
    duration: "10 min",
    focus: "Preparar articulaciones y subir temperatura",
    image: IMG.calentamiento,
    imageCaption: "Referencia · zancada dinámica con rotación",
    accent: "mustard",
    exercises: [
      { id: "a1", name: "Movilidad articular", scheme: "1 × 8 por articulación", rest: "—", defaultVideo: VIDEOS.calentamiento, cues: ["Comienza por el cuello: gira suavemente de lado a lado, 8 veces", "Continúa con los hombros: círculos hacia adelante y hacia atrás", "Sigue con las muñecas, caderas y rodillas: movimientos circulares", "Termina con los tobillos: rota en ambas direcciones", "Movimiento lento y controlado, sin rebotes ni dolor"] },
      { id: "a2", name: "Trote suave en el lugar", scheme: "4 min", rest: "—", defaultVideo: VIDEOS.trote, cues: ["Levanta las rodillas suavemente, no necesitas ir alto", "Mantén una postura erguida, hombros relajados", "Respira por la nariz: inhala 2 pasos, exhala 2 pasos", "Si te cansas, camina en el lugar sin dejar de moverte", "El objetivo es subir la temperatura corporal, no cansarte"] },
      { id: "a3", name: "Zancada dinámica + rotación", scheme: "2 × 10 por lado", rest: "30 s", defaultVideo: VIDEOS.zancada, cues: ["Da un paso largo hacia adelante con la pierna derecha", "Baja la rodilla trasera cerca del suelo (sin tocarlo)", "Mantén el torso erguido y gira hacia el lado de la pierna adelantada", "Vuelve a la posición inicial y repite con la otra pierna", "Movimiento controlado, no pierdas el equilibrio"] },
      { id: "a4", name: "Flexión escapular (en pared)", scheme: "2 × 12", rest: "45 s", defaultVideo: VIDEOS.flexionEscapular, cues: ["Colócate frente a una pared, brazos estirados a la altura de los hombros", "Mantén los codos completamente estirados durante todo el movimiento", "Empuja la pared alejando los omóplatos", "Luego acerca los omóplatos entre sí", "Movimiento lento y controlado, solo se mueven los omóplatos"] },
    ],
  },
  {
    id: "habituales",
    num: "02",
    title: "Ejercicios habituales",
    kicker: "Fuerza base · con video",
    duration: "32 min",
    focus: "Patrones principales con referencia visual",
    dark: true,
    image: IMG.sentadilla,
    imageCaption: "Referencia · sentadilla asistida con silla",
    accent: "ember",
    note: "Cada ejercicio tiene su propio espacio de video: pega un enlace de YouTube o un archivo .mp4 y quedará guardado en este dispositivo.",
    exercises: [
      { id: "sentadilla", name: "Sentadilla asistida con silla", scheme: "3 × 10", rest: "90 s", tag: "Patrón principal", image: IMG.sentadilla, imageLabel: "Sentadilla asistida con silla", defaultVideo: VIDEOS.sentadilla, cues: ["Colócate frente a una silla estable, pies separados al ancho de los hombros", "Extiende los brazos hacia adelante para mantener el equilibrio", "Baja lentamente como si fueras a sentarte, controlando el movimiento", "Apenas toca la silla con el trasero, vuelve a subir empujando con los talones", "Mantén la espalda recta y las rodillas en línea con los pies"] },
      { id: "flexiones", name: "Flexiones contra la pared", scheme: "3 × 12", rest: "90 s", tag: "Empuje horizontal", image: IMG.flexiones, imageLabel: "Flexión contra pared", defaultVideo: VIDEOS.flexiones, cues: ["Colócate frente a una pared, a un paso de distancia", "Apoya las manos en la pared a la altura de los hombros", "Inclina el cuerpo hacia la pared doblando los codos", "Empuja para volver a la posición inicial", "Mantén el cuerpo recto como una tabla"] },
      { id: "plancha", name: "Plancha modificada (de rodillas)", scheme: "3 × 30 s", rest: "60 s", tag: "Core anti-extensión", image: IMG.plancha, imageLabel: "Plancha de rodillas", defaultVideo: VIDEOS.plancha, cues: ["Apóyate sobre los antebrazos y las rodillas", "Mantén una línea recta desde la cabeza hasta las rodillas", "Aprieta el abdomen como si fueras a recibir un golpe", "No dejes que la cadera suba o baje", "Respira normalmente"] },
      { id: "remo", name: "Remada isométrica en marco de puerta", scheme: "3 × 10", rest: "90 s", tag: "Tracción horizontal", image: IMG.remo, imageLabel: "Remada isométrica", defaultVideo: VIDEOS.remada, cues: ["Colócate frente al marco de una puerta abierta", "Agarra el marco con ambas manos a la altura del pecho", "Da un paso hacia adelante y deja que tu cuerpo se incline hacia atrás", "Tira de tu cuerpo hacia el marco apretando los omóplatos", "Mantén 1 segundo arriba y vuelve a la posición inicial"] },
    ],
  },
  {
    id: "circuito",
    num: "03",
    title: "Circuito metabólico",
    kicker: "EMOM 12 min",
    duration: "12 min",
    focus: "Capacidad de trabajo a intensidad media-alta",
    image: IMG.circuito,
    imageCaption: "Referencia · cuerdas de batalla",
    accent: "cobalt",
    exercises: [
      { id: "c1", name: "Marcha en el lugar (alta intensidad)", scheme: "30 s", rest: "resto del minuto", defaultVideo: VIDEOS.cuerdas, cues: ["Levanta las rodillas lo más alto que puedas", "Mueve los brazos como si estuvieras corriendo", "Mantén un ritmo rápido pero controlado", "Respira de forma constante"] },
      { id: "c2", name: "Sentadilla + elevación de talones", scheme: "12 reps", rest: "resto del minuto", defaultVideo: VIDEOS.burpees, cues: ["Baja en sentadilla manteniendo la espalda recta", "Al subir, eleva los talones del suelo", "Extiende los brazos hacia arriba", "Movimiento fluido y controlado"] },
      { id: "c3", name: "Sentadilla isométrica contra la pared", scheme: "30 s", rest: "resto del minuto", defaultVideo: VIDEOS.goblet, cues: ["Apoya la espalda contra una pared", "Desliza hacia abajo hasta que las rodillas formen 90 grados", "Mantén la posición 30 segundos", "Respira normalmente"] },
      { id: "c4", name: "Caminata en el lugar (recuperación)", scheme: "resto del minuto", rest: "—", defaultVideo: VIDEOS.trote, cues: ["Camina suavemente en el lugar", "Respira profundo por la nariz", "Deja que tu ritmo cardíaco baje", "Prepárate para la siguiente estación"] },
    ],
  },
  {
    id: "calma",
    num: "04",
    title: "Vuelta a la calma",
    kicker: "Respiración y movilidad",
    duration: "8 min",
    focus: "Bajar pulsaciones y soltar tejidos cargados",
    dark: true,
    image: IMG.estiramiento,
    imageCaption: "Referencia · estiramiento de isquios",
    accent: "ember",
    exercises: [
      { id: "d1", name: "Estiramiento de isquios (sentado)", scheme: "2 × 40 s por lado", rest: "20 s", defaultVideo: VIDEOS.estiramientoIsquios, cues: ["Siéntate en el borde de una silla con la espalda recta", "Extiende una pierna hacia adelante con el talón en el suelo", "Inclínate ligeramente hacia adelante desde la cadera", "Debes sentir un estiramiento suave en la parte posterior del muslo", "Mantén 40 segundos y cambia de pierna"] },
      { id: "d2", name: "Estiramiento de cuádriceps sentado", scheme: "2 × 40 s por lado", rest: "20 s", defaultVideo: VIDEOS.estiramientoPsoas, image: IMG.cuadriceps, imageLabel: "Estiramiento de cuádriceps sentado", cues: ["Siéntate en el borde de una silla estable con la espalda recta", "Dobla una rodilla hacia atrás y sujeta el tobillo con la mano", "Mantén la otra pierna apoyada en el suelo con el pie plano", "Debes sentir un estiramiento en la parte frontal del muslo", "Mantén 40 segundos y cambia de pierna"] },
      { id: "d3", name: "Apertura torácica (sentado)", scheme: "2 × 10", rest: "20 s", defaultVideo: VIDEOS.aperturaToracica, cues: ["Siéntate en una silla con la espalda recta", "Entrelaza los dedos detrás de la nuca", "Abre los codos hacia los lados y hacia atrás", "Mantén el pecho abierto y los hombros relajados", "Exhala al abrir, inhala al cerrar"] },
      { id: "d4", name: "Respiración en caja 4-4-4-4", scheme: "2 min", rest: "—", defaultVideo: VIDEOS.respiracion, cues: ["Siéntate cómodamente con la espalda recta", "Inhala por la nariz contando hasta 4", "Mantén el aire contando hasta 4", "Exhala por la boca contando hasta 4", "Mantén sin aire contando hasta 4, repite durante 2 minutos"] },
    ],
  },
];

export const MARQUEE_CUES = ["Espalda neutra", "Rango completo", "Técnica > peso", "Talones al suelo", "Core apretado", "Ritmo controlado", "Respira", "Sin prisa"];
export const TOTAL_EXERCISES = BLOCKS.reduce((acc, b) => acc + b.exercises.length, 0);
export const TOTAL_MINUTES = 62;
