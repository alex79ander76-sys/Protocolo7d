export type ParsedVideo =
  | { kind: "youtube"; id: string }
  | { kind: "file"; src: string };

export function parseVideoUrl(raw: string): ParsedVideo | null {
  const url = raw.trim();
  if (!url) return null;
  if (!/^https?:\/\/\S+$/i.test(url)) return null;
  const yt = url.match(
    /(?:youtube\.com\/(?:watch\?(?:[^#]*&)?v=|shorts\/|embed\/|live\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/i
  );
  if (yt) return { kind: "youtube", id: yt[1] };
  return { kind: "file", src: url };
}

export function videoKindLabel(parsed: ParsedVideo): string {
  return parsed.kind === "youtube"
    ? "YouTube detectado · se insertará como embed"
    : "Video directo detectado (.mp4 / .webm / .mov)";
}
