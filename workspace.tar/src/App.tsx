import { HashRouter, Route, Routes } from "react-router-dom";
import { ToastProvider } from "./components/Toast";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import Nutrition from "./pages/Nutrition";

export default function App() {
  return (
    <ToastProvider>
      <HashRouter>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/alimentacion" element={<Nutrition />} />
        </Routes>
      </HashRouter>
    </ToastProvider>
  );
}
