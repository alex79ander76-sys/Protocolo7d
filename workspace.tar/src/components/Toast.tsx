import { createContext, useCallback, useContext, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";

type Kind = "success" | "error" | "info";
type Toast = { id: number; kind: Kind; title: string; desc?: string };

const ToastCtx = createContext<{ push: (t: Omit<Toast, "id">) => void; toast: (title: string, kind?: Kind, desc?: string) => void }>({
  push: () => {},
  toast: () => {},
});

export const useToast = () => useContext(ToastCtx);

const BAR: Record<Kind, string> = { success: "bg-leaf", error: "bg-red-500", info: "bg-mustard" };

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);

  const push = useCallback((t: Omit<Toast, "id">) => {
    const id = Date.now() + Math.random();
    setItems((s) => [...s.slice(-3), { ...t, id }]);
    window.setTimeout(() => setItems((s) => s.filter((i) => i.id !== id)), 3600);
  }, []);

  const toast = useCallback((title: string, kind: Kind = "info", desc?: string) => push({ kind, title, desc }), [push]);

  return (
    <ToastCtx.Provider value={{ push, toast }}>
      {children}
      <div className="pointer-events-none fixed right-4 bottom-4 z-[130] flex w-[calc(100%-2rem)] max-w-sm flex-col gap-2">
        <AnimatePresence>
          {items.map((t) => (
            <motion.button key={t.id} type="button" onClick={() => setItems((s) => s.filter((i) => i.id !== t.id))}
              initial={{ opacity: 0, x: 40, scale: 0.96 }} animate={{ opacity: 1, x: 0, scale: 1 }} exit={{ opacity: 0, x: 30, scale: 0.96 }}
              transition={{ type: "spring", stiffness: 400, damping: 32 }}
              className="pointer-events-auto relative overflow-hidden border border-line-dark bg-ink px-4 py-3 text-left shadow-[6px_6px_0_rgba(22,24,29,0.25)]">
              <span className={`absolute inset-y-0 left-0 w-1.5 ${BAR[t.kind]}`} />
              <span className="flex items-start gap-3 pl-2">
                <span>
                  <span className="block text-sm font-semibold text-bone">{t.title}</span>
                  {t.desc && <span className="mt-0.5 block text-xs text-bone/60">{t.desc}</span>}
                </span>
              </span>
            </motion.button>
          ))}
        </AnimatePresence>
      </div>
    </ToastCtx.Provider>
  );
}
