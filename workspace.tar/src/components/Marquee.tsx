export default function Marquee({ items }: { items: string[] }) {
  const row = [...items, ...items];
  return (
    <div className="relative z-10 overflow-hidden border-y-2 border-ink bg-ink py-2.5">
      <div className="marquee-track">
        {row.map((item, i) => (
          <span key={i} className="flex items-center gap-6 pr-6 text-sm font-bold tracking-[0.22em] whitespace-nowrap text-bone uppercase">
            <svg viewBox="0 0 24 24" className="h-3 w-3 text-ember" fill="currentColor"><path d="M12 2l3.2 6.8L22 12l-6.8 3.2L12 22l-3.2-6.8L2 12l6.8-3.2z" /></svg>
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}
