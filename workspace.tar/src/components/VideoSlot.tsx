import { parseVideoUrl } from "../lib/video";
import type { Exercise } from "../data/routine";

type Props = {
  exercise: Exercise;
  video: string | null;
  onAdd: () => void;
  onRemove: () => void;
};

export default function VideoSlot({ exercise, video, onAdd, onRemove }: Props) {
  const parsed = video ? parseVideoUrl(video) : null;

  return (
    <div>
      {video && parsed ? (
        <div className="border-2 border-line-dark bg-black">
          {parsed.kind === "youtube" ? (
            <iframe src={`https://www.youtube-nocookie.com/embed/${parsed.id}?rel=0`} title={`Video de ${exercise.name}`}
              className="aspect-video w-full border-0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
          ) : (
            <video src={parsed.src} poster={exercise.image} controls preload="metadata" playsInline className="aspect-video w-full bg-black object-contain" />
          )}
        </div>
      ) : (
        <button type="button" onClick={onAdd}
          className="group relative block aspect-video w-full overflow-hidden border-2 border-dashed border-line-dark text-left transition-colors duration-300 hover:border-ember focus-visible:border-ember focus-visible:outline-none"
          aria-label={`Colocar video en ${exercise.name}`}>
          {exercise.image && <img src={exercise.image} alt={`Referencia técnica de ${exercise.name}`} className="absolute inset-0 h-full w-full object-cover opacity-70 transition-transform duration-700 ease-out group-hover:scale-[1.06]" loading="lazy" />}
          <span className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/30 to-ink/10" />
          <span className="absolute top-3 left-3 border border-bone/40 bg-ink/60 px-2 py-1 text-[10px] font-bold tracking-[0.18em] text-bone uppercase">Sin video</span>
          <span className="absolute inset-0 grid place-items-center">
            <span className="flex flex-col items-center gap-3 px-6 text-center">
              <span className="grid h-16 w-16 place-items-center border-2 border-dashed border-bone/70 text-bone transition-all duration-300 group-hover:scale-110 group-hover:border-ember group-hover:bg-ember group-hover:text-bone">
                <svg viewBox="0 0 24 24" className="ml-1 h-7 w-7" fill="currentColor"><path d="M7 4.5v15l13-7.5-13-7.5z" /></svg>
              </span>
              <span className="font-display text-2xl tracking-wide text-bone uppercase">Colocar video</span>
              <span className="max-w-[26ch] text-xs text-bone/70">Pega un enlace de YouTube o un archivo .mp4 para desarrollar este ejercicio</span>
            </span>
          </span>
        </button>
      )}
      <div className="flex items-center justify-between gap-2 border border-t-0 border-line-dark bg-ink px-3 py-2">
        {video && parsed ? (
          <>
            <span className="bg-leaf px-2 py-0.5 text-[10px] font-bold tracking-[0.16em] text-bone uppercase">Video colocado</span>
            <span className="flex items-center gap-1.5">
              <button onClick={onAdd} className="border border-bone/25 px-2.5 py-1 text-[11px] font-semibold tracking-wide text-bone/85 uppercase transition-colors hover:border-ember hover:text-bone">Cambiar</button>
              <button onClick={onRemove} className="border border-bone/25 px-2.5 py-1 text-[11px] font-semibold tracking-wide text-bone/85 uppercase transition-colors hover:border-ember hover:bg-ember hover:text-bone">Quitar</button>
            </span>
          </>
        ) : (
          <span className="text-[11px] tracking-wide text-bone/50 uppercase">Espacio de video · YouTube o .mp4</span>
        )}
      </div>
      {exercise.imageLabel && (
        <p className="mt-2 flex items-center gap-1.5 text-[11px] text-paper/55">
          <span className="text-ember"><svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="7" width="13" height="12" /><path d="M16 10.5l5-3v9l-5-3" /></svg></span>
          Imagen de referencia — {exercise.imageLabel}
        </p>
      )}
    </div>
  );
}
