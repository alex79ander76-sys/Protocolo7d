import { Link, useLocation } from "react-router-dom";
import type { ReactNode } from "react";

export default function TopNav({ right }: { right?: ReactNode }) {
  const { pathname } = useLocation();
  const links = [
    { to: "/", label: "Entrenamiento", icon: "🏋️" },
    { to: "/alimentacion", label: "Alimentación", icon: "🍽️" },
  ];
  const visibleLinks = links.filter((l) => l.to !== pathname);

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b-2 border-ink bg-bone/95 backdrop-blur">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
        <div className="flex items-center gap-2 cursor-default">
          <span className="grid h-9 w-9 place-items-center bg-ink text-bone">🏋️</span>
          <span className="font-display text-base sm:text-lg tracking-wide text-ink uppercase">Pizarra</span>
        </div>
        <nav className="flex items-center gap-2">
          {visibleLinks.map((l) => (
            <Link key={l.to} to={l.to} className="flex items-center gap-1.5 border-2 border-transparent px-3 py-1.5 text-xs font-bold tracking-wide uppercase transition-colors hover:border-ink hover:text-ink text-ink/60 sm:text-sm">
              <span>{l.icon}</span>
              <span>{l.label}</span>
            </Link>
          ))}
        </nav>
        {right && <div className="flex items-center gap-3">{right}</div>}
      </div>
    </header>
  );
}
