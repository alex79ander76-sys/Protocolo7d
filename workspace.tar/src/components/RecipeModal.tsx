import { AnimatePresence, motion } from "framer-motion";
import type { MealOption } from "../data/meals";

type Props = { meal: MealOption | null; onClose: () => void };

export default function RecipeModal({ meal, onClose }: Props) {
  if (!meal) return null;

  return (
    <AnimatePresence>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-[110] flex items-center justify-center bg-ink/70 p-4 backdrop-blur-[2px]" onClick={onClose}>
        <motion.div initial={{ opacity: 0, y: 24, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 16, scale: 0.97 }}
          transition={{ type: "spring", stiffness: 380, damping: 32 }}
          className="w-full max-w-2xl border-2 border-ink bg-bone shadow-[10px_10px_0_rgba(46,107,255,0.9)] max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true" aria-label={`Receta de ${meal.name}`}>
          <div className="flex items-center justify-between border-b-2 border-ink bg-ink px-5 py-3">
            <p className="font-display text-lg tracking-wide text-bone uppercase">Receta</p>
            <button onClick={onClose} aria-label="Cerrar" className="grid h-8 w-8 place-items-center border border-bone/30 text-bone transition-colors hover:bg-ember hover:border-ember">
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.4"><path d="M6 6l12 12M18 6L6 18" strokeLinecap="square" /></svg>
            </button>
          </div>
          <div className="p-5">
            <div className="mb-5 overflow-hidden border-2 border-ink">
              <img src={meal.img} alt={meal.name} className="aspect-[16/9] w-full object-cover" />
            </div>
            <h2 className="font-display text-3xl tracking-wide uppercase">{meal.name}</h2>
            <p className="mt-2 text-base text-ink/80">{meal.desc}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <span className="border border-ink/25 px-2 py-0.5 text-xs font-bold tracking-wider text-ink/70 uppercase">{meal.tag}</span>
            </div>
            {meal.ingredients && meal.ingredients.length > 0 && (
              <div className="mt-6">
                <h3 className="font-display mb-3 flex items-center gap-2 text-xl tracking-wide uppercase">
                  <svg viewBox="0 0 24 24" className="h-5 w-5 text-ember" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" strokeLinecap="square" /></svg>
                  Ingredientes
                </h3>
                <ul className="space-y-2">
                  {meal.ingredients.map((ingredient, i) => (
                    <li key={i} className="flex items-start gap-3 text-base text-ink/90"><span className="mt-1 text-ember">•</span>{ingredient}</li>
                  ))}
                </ul>
              </div>
            )}
            {meal.steps && meal.steps.length > 0 && (
              <div className="mt-6">
                <h3 className="font-display mb-3 flex items-center gap-2 text-xl tracking-wide uppercase">
                  <svg viewBox="0 0 24 24" className="h-5 w-5 text-ember" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" strokeLinecap="square" /></svg>
                  Preparación
                </h3>
                <ol className="space-y-3">
                  {meal.steps.map((step, i) => (
                    <li key={i} className="flex items-start gap-3 text-base text-ink/90">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-ember text-sm font-bold text-bone">{i + 1}</span>
                      <span className="pt-0.5">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>
            )}
            <div className="mt-6 border-t border-ink/15 pt-4">
              <button onClick={onClose} className="w-full bg-ember px-4 py-3 font-display text-lg tracking-wide text-bone uppercase transition-colors hover:bg-ink">Cerrar receta</button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
