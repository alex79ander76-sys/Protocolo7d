import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { parseVideoUrl, videoKindLabel } from "../lib/video";

type Props = {
  open: boolean;
  exerciseName: string;
  initial: string;
  onSave: (url: string) => void;
  onClose: () => void;
};

export default function VideoModal({ open, exerciseName, initial, onSave, onClose }: Props) {
  const [url, setUrl] = useState(initial);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setUrl(initial);
      window.setTimeout(() => inputRef.current?.focus(), 60);
    }
  }, [open, initial]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const trimmed = url.trim();
  const parsed = trimmed ? parseVideoUrl(trimmed) : null;
  const invalid = trimmed.length > 0 && parsed === null;

  return (
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-[110] flex items-center justify-center bg-ink/70 p-4 backdrop-blur-[2px]"
          onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
          <motion.div initial={{ opacity: 0, y: 24, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 16, scale: 0.97 }}
            transition={{ type: "spring", stiffness: 380, damping: 32 }}
            className="w-full max-w-lg border-2 border-ink bg-bone shadow-[10px_10px_0_rgba(46,107,255,0.9)]"
            role="dialog" aria-modal="true" aria-label={`Colocar video en ${exerciseName}`}
            onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b-2 border-ink bg-ink px-5 py-3">
              <p className="font-display text-lg tracking-wide text-bone uppercase">Colocar video</p>
              <button onClick={onClose} aria-label="Cerrar" className="grid h-8 w-8 place-items-center border border-bone/30 text-bone transition-colors hover:bg-ember hover:border-ember">
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.4"><path d="M6 6l12 12M18 6L6 18" strokeLinecap="square" /></svg>
              </button>
            </div>
            <div className="p-5">
              <p className="text-sm text-ink/60">Ejercicio: <span className="font-semibold text-ink">{exerciseName}</span></p>
              <label className="mt-4 block">
                <span className="text-xs font-semibold tracking-widest text-ink/50 uppercase">Enlace del video</span>
                <input ref={inputRef} value={url} onChange={(e) => setUrl(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter" && parsed) onSave(trimmed); }}
                  placeholder="https://youtube.com/watch?v=…  o  https://…/ejercicio.mp4"
                  className={`mt-1.5 w-full border-2 bg-paper px-3 py-2.5 text-sm text-ink outline-none transition-colors placeholder:text-ink/30 focus:border-ember ${invalid ? "border-red-500" : "border-ink"}`} />
              </label>
              <div className="mt-3 min-h-6">
                {parsed && <p className="flex items-center gap-2 text-xs font-semibold text-leaf"><svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2.6"><path d="M4 12.5l5 5L20 6.5" strokeLinecap="square" /></svg>{videoKindLabel(parsed)}</p>}
                {invalid && <p className="flex items-center gap-2 text-xs font-semibold text-red-500"><svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2.6"><path d="M12 4v9M12 16.5v.5" strokeLinecap="square" /><circle cx="12" cy="12" r="9" /></svg>El enlace no es válido</p>}
              </div>
              <div className="mt-5 flex items-center gap-3">
                <button onClick={onClose} className="border-2 border-ink px-4 py-2.5 text-sm font-semibold uppercase tracking-wide transition-colors hover:bg-ink hover:text-bone">Cancelar</button>
                <button onClick={() => parsed && onSave(trimmed)} disabled={!parsed}
                  className="flex-1 bg-ember px-4 py-2.5 text-sm font-bold tracking-wide text-bone uppercase transition-all enabled:hover:bg-ink disabled:cursor-not-allowed disabled:opacity-35">Guardar video</button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
