import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import confetti from "canvas-confetti";
import Reveal from "../components/Reveal";
import Marquee from "../components/Marquee";
import TopNav from "../components/TopNav";
import RecipeModal from "../components/RecipeModal";
import { useToast } from "../components/Toast";
import { DAYS, FOOD_IMG, HOUSE_RULES, MEAL_POOLS, PLATE_SEGMENTS, SLOTS, SLOT_LABEL, TOTAL_MENU_OPTIONS, pickMeal, type MealSlot } from "../data/meals";

type MenuState = { week: number; done: boolean[]; swaps: Record<string, number> };
const KEY = "pizarra40.menu.v1";
const defaultState = (): MenuState => ({ week: 0, done: DAYS.map(() => false), swaps: {} });

function loadState(): MenuState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw) as Partial<MenuState>;
    if (typeof parsed.week !== "number" || !Array.isArray(parsed.done)) return defaultState();
    return { week: parsed.week, done: DAYS.map((_, i) => parsed.done![i] === true), swaps: typeof parsed.swaps === "object" && parsed.swaps ? parsed.swaps : {} };
  } catch { return defaultState(); }
}

function PlateFallback() {
  return <div className="grid h-full w-full place-items-center bg-ink-2"><svg viewBox="0 0 24 24" className="h-7 w-7 text-paper/40" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="8.5" /><circle cx="12" cy="12" r="4" /></svg></div>;
}

function MealThumb({ src, alt }: { src: string; alt: string }) {
  const [failed, setFailed] = useState(false);
  return (
    <div className="-mx-4 -mt-4 mb-3 h-24 overflow-hidden border-b-2 border-line">
      {failed ? <PlateFallback /> : <img src={src} alt={alt} loading="lazy" onError={() => setFailed(true)} className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover/meal:scale-110" />}
    </div>
  );
}

export default function Nutrition() {
  const { push, toast } = useToast();
  const [state, setState] = useState<MenuState>(loadState);
  const [armedReset, setArmedReset] = useState(false);
  const [activeSeg, setActiveSeg] = useState<string | null>(null);
  const [recipeMeal, setRecipeMeal] = useState<ReturnType<typeof pickMeal> | null>(null);

  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch {} }, [state]);
  useEffect(() => { if (!armedReset) return; const id = window.setTimeout(() => setArmedReset(false), 3000); return () => window.clearTimeout(id); }, [armedReset]);

  const todayIdx = (new Date().getDay() + 6) % 7;
  const completedCount = state.done.filter(Boolean).length;
  const allDone = completedCount === 7;

  const meals = useMemo(() => {
    const map: Record<string, ReturnType<typeof pickMeal>> = {};
    DAYS.forEach((_, dayIdx) => { SLOTS.forEach((slot) => { map[`${dayIdx}-${slot}`] = pickMeal(slot, dayIdx, state.week, state.swaps[`${dayIdx}-${slot}`] ?? 0); }); });
    return map;
  }, [state.week, state.swaps]);

  const toggleDone = (i: number) => {
    setState((s) => {
      const done = s.done.map((d, j) => (j === i ? !d : d));
      if (done.filter(Boolean).length === 7) {
        window.setTimeout(() => { toast("¡Semana completa!", "success", "Generador de menús desbloqueado."); confetti({ particleCount: 120, spread: 75, origin: { y: 0.6 } }); }, 120);
      }
      return { ...s, done };
    });
  };

  const swapMeal = (dayIdx: number, slot: MealSlot) => {
    const key = `${dayIdx}-${slot}`;
    setState((s) => ({ ...s, swaps: { ...s.swaps, [key]: (s.swaps[key] ?? 0) + 1 } }));
    toast(`${SLOT_LABEL[slot]} del ${DAYS[dayIdx].name} intercambiada.`, "info");
  };

  const generateWeek = () => {
    setState((s) => ({ week: s.week + 1, done: DAYS.map(() => false), swaps: {} }));
    confetti({ particleCount: 180, spread: 90, origin: { y: 0.5 } });
    toast(`Semana ${state.week + 2} generada.`, "success");
  };

  const resetAll = () => {
    if (!armedReset) { setArmedReset(true); return; }
    setArmedReset(false);
    setState(defaultState());
    toast("Semana reiniciada.", "info");
  };

  return (
    <div id="top" className="min-h-screen bg-paper text-ink pt-16">
      <TopNav right={<div className="hidden items-center gap-2 border-2 border-ink bg-bone px-3 py-1.5 sm:flex"><span className={`h-2 w-2 rounded-full ${allDone ? "bg-leaf" : "bg-ember"} blink-dot`} /><span className="tabular text-xs font-bold uppercase">Semana {state.week + 1} · {completedCount}/7</span></div>} />

      {/* Apertura */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -top-10 right-0 select-none font-display text-[18vw] leading-none text-ink/[0.04] sm:text-[26vw]" aria-hidden="true">DIET</div>
        <div className="relative mx-auto max-w-6xl px-4 pt-10 pb-12 sm:px-6 sm:pt-16">
          <div className="grid items-center gap-10 lg:grid-cols-[1.15fr_1fr]">
            <div>
              <Reveal>
                <p className="mb-5 inline-flex items-center gap-2 border-2 border-ink bg-mustard px-3 py-1.5 text-xs font-bold uppercase"><span className="h-2 w-2 bg-ink blink-dot" />La base del sistema · +40 · cero dietas</p>
                <h1 className="font-display text-[10vw] leading-[0.92] uppercase sm:text-6xl lg:text-8xl">Primero,<br /><span className="text-ember">el plato.</span></h1>
                <p className="mt-6 max-w-xl text-base text-ink/70 sm:text-lg">Aquí no se cuenta nada: se construye <strong className="text-ink">costumbre</strong>. Un plan de 7 días con comidas normales y fáciles.</p>
              </Reveal>
              <Reveal delay={0.12}>
                <div className="mt-8 flex flex-wrap gap-3">
                  {[["7 días", "de plan"], ["4 comidas", "al día"], [`${TOTAL_MENU_OPTIONS} menús`, "intercambiables"], ["0 calorías", "contadas"]].map(([big, small]) => (
                    <div key={big} className="border-2 border-ink bg-bone px-4 py-2.5">
                      <p className="font-display text-xl uppercase">{big}</p>
                      <p className="mt-1 text-[10px] font-semibold uppercase text-ink/50">{small}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                  <button onClick={() => document.getElementById("plan")?.scrollIntoView({ behavior: "smooth" })} className="bg-ember px-5 py-3 font-display text-base uppercase text-bone hover:bg-ink sm:px-7 sm:text-xl">Ir al plan semanal</button>
                  <button onClick={() => document.getElementById("reglas")?.scrollIntoView({ behavior: "smooth" })} className="border-2 border-ink px-5 py-3 font-display text-base uppercase hover:bg-ink hover:text-bone sm:px-7 sm:text-xl">Reglas de la casa</button>
                </div>
              </Reveal>
            </div>
            <Reveal delay={0.15}>
              <div className="group relative">
                <div className="overflow-hidden border-2 border-ink shadow-[12px_12px_0_rgba(22,24,29,1)]">
                  <img src={FOOD_IMG.plato} alt="Plato base" className="aspect-[4/3] w-full object-cover transition-transform duration-[1600ms] ease-out group-hover:scale-[1.05]" />
                </div>
                <div className="absolute -top-4 -right-3 rotate-6 border-2 border-ink bg-ember px-4 py-2 text-center shadow-[4px_4px_0_rgba(22,24,29,1)] transition-transform duration-300 group-hover:rotate-0">
                  <p className="font-display text-lg uppercase text-bone">0 dietas</p>
                  <p className="text-[10px] font-bold uppercase text-bone/80">100% hábito</p>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <Marquee items={["Proteína en cada comida", "Mitad del plato: verdura", "Agua primero", "Cena temprano", "80/20 siempre", "Mastica despacio", "Sin contar calorías", "Constumbre > dieta"]} />

      {/* Reglas */}
      <section id="reglas" className="relative scroll-mt-20 py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="grid gap-10 lg:grid-cols-2">
            <div>
              <Reveal>
                <p className="text-xs font-bold uppercase text-ember">— Las reglas de la casa</p>
                <h2 className="mt-3 font-display text-4xl uppercase sm:text-6xl">Cinco reglas.<br /><span className="text-outline-ink">Ninguna báscula.</span></h2>
              </Reveal>
              <div className="mt-10">
                {HOUSE_RULES.map((rule, i) => (
                  <Reveal key={rule.title} delay={i * 0.05}>
                    <div className="group flex gap-5 border-t-2 border-ink py-5 hover:bg-bone">
                      <span className="font-display text-3xl text-outline-ember group-hover:text-ember">{String(i + 1).padStart(2, "0")}</span>
                      <div>
                        <h3 className="font-display text-2xl uppercase">{rule.title}</h3>
                        <p className="mt-1.5 max-w-md text-sm text-ink/65">{rule.desc}</p>
                      </div>
                    </div>
                  </Reveal>
                ))}
                <div className="border-t-2 border-ink" />
              </div>
            </div>
            <Reveal delay={0.1} className="lg:sticky lg:top-24 lg:self-start">
              <div className="border-2 border-ink bg-ink p-6 text-paper">
                <p className="text-xs font-bold uppercase text-mustard">El plato base · pasa el cursor</p>
                <svg viewBox="0 0 200 200" className="mx-auto mt-6 w-full max-w-[340px]">
                  <circle cx="100" cy="100" r="97" fill="none" stroke="#363b48" strokeWidth="2" />
                  {PLATE_SEGMENTS.map((seg, i) => {
                    const d = i === 0 ? "M100,100 L10,100 A90,90 0 0 1 190,100 Z" : i === 1 ? "M100,100 L10,100 A90,90 0 0 0 100,190 Z" : "M100,100 L100,190 A90,90 0 0 0 190,100 Z";
                    const active = activeSeg === seg.id;
                    return <path key={seg.id} d={d} fill={seg.color} stroke="#16181d" strokeWidth="2" opacity={activeSeg === null || active ? 1 : 0.35} className="cursor-pointer transition-all duration-300" onMouseEnter={() => setActiveSeg(seg.id)} onMouseLeave={() => setActiveSeg(null)} tabIndex={0} />;
                  })}
                  <text x="100" y="62" textAnchor="middle" className="fill-[#f6f5ef] font-bold" fontSize="11">VERDURA 50%</text>
                  <text x="57" y="148" textAnchor="middle" className="fill-[#f6f5ef] font-bold" fontSize="9">PROTEÍNA</text>
                  <text x="143" y="148" textAnchor="middle" className="fill-[#16181d] font-bold" fontSize="9">CARBO 25%</text>
                </svg>
                <div className="mt-6 space-y-3">
                  {PLATE_SEGMENTS.map((seg) => (
                    <div key={seg.id} onMouseEnter={() => setActiveSeg(seg.id)} onMouseLeave={() => setActiveSeg(null)} className={`cursor-default border-l-4 px-3 py-2 transition-all duration-300 ${activeSeg === seg.id ? "bg-paper/10" : "opacity-70"}`} style={{ borderColor: seg.color }}>
                      <p className="flex items-baseline gap-2 font-display text-lg uppercase">{seg.label}<span className="text-xs text-paper/50">{seg.pct}</span></p>
                      <p className="mt-0.5 text-xs text-paper/60">{seg.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Plan semanal */}
      <section id="plan" className="relative scroll-mt-20 border-t-2 border-ink bg-bone py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <Reveal>
            <div className="flex flex-wrap items-end justify-between gap-6">
              <div>
                <p className="text-xs font-bold uppercase text-ember">— El plan · semana {state.week + 1}</p>
                <h2 className="mt-3 font-display text-4xl uppercase sm:text-6xl">Siete días,<br /><span className="text-outline-ink">todo intercambiable.</span></h2>
              </div>
              <div className="w-full max-w-sm">
                <div className="flex items-center justify-between text-xs font-bold uppercase">
                  <span className="text-ink/60">Progreso de la semana</span>
                  <span className="tabular">{completedCount}/7 días</span>
                </div>
                <div className="mt-2 flex gap-1.5">
                  {DAYS.map((d, i) => <div key={d.num} title={`Día ${d.num} · ${d.name}`} className={`h-3 flex-1 border-2 border-ink transition-colors duration-300 ${state.done[i] ? "bg-leaf" : i === todayIdx ? "bg-mustard" : "bg-paper"}`} />)}
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.05}>
            <figure className="group relative mt-10 overflow-hidden border-2 border-ink shadow-[12px_12px_0_rgba(46,107,255,0.35)]">
              <img src={FOOD_IMG.despensa} alt="Despensa base" className="aspect-[21/8] w-full object-cover transition-transform duration-[1600ms] ease-out group-hover:scale-[1.04]" />
              <figcaption className="absolute inset-x-0 bottom-0 flex flex-wrap items-baseline gap-x-4 gap-y-1 bg-gradient-to-t from-ink/90 via-ink/45 to-transparent px-5 pt-12 pb-4">
                <span className="font-display text-2xl uppercase text-bone sm:text-3xl">La despensa base</span>
                <span className="text-xs text-bone/75">Proteína, verdura, legumbre y aceite de oliva</span>
              </figcaption>
            </figure>
          </Reveal>

          <div className="mt-10 space-y-5">
            {DAYS.map((day, dayIdx) => {
              const done = state.done[dayIdx];
              const isToday = dayIdx === todayIdx;
              return (
                <Reveal key={day.num} delay={Math.min(dayIdx * 0.04, 0.2)}>
                  <article className={`relative border-2 border-ink transition-colors duration-300 ${done ? "bg-leaf/[0.07]" : "bg-bone hover:bg-paper"}`}>
                    {isToday && <span className="absolute -top-3 left-4 z-10 bg-ember px-2.5 py-0.5 text-[10px] font-bold uppercase text-bone">Hoy</span>}
                    <div className="grid lg:grid-cols-[120px_1fr_96px]">
                      <div className={`flex items-center gap-4 border-b-2 border-ink px-4 py-4 lg:flex-col lg:items-start lg:justify-center lg:gap-1 lg:border-r-2 lg:border-b-0 lg:py-6 ${done ? "bg-leaf text-bone" : "bg-ink text-bone"}`}>
                        <p className="font-display text-4xl">{day.num}</p>
                        <div>
                          <p className="font-display text-lg uppercase">{day.name}</p>
                          <p className={`mt-1 text-[10px] font-semibold uppercase ${done ? "text-bone/75" : "text-paper/50"}`}>{done ? "Completado" : "En juego"}</p>
                        </div>
                      </div>
                      <div className="grid divide-y-2 divide-line sm:grid-cols-2 sm:divide-x-2 sm:divide-y-0 lg:grid-cols-4 lg:divide-x-2 lg:divide-y-0">
                        {SLOTS.map((slot) => {
                          const meal = meals[`${dayIdx}-${slot}`];
                          return (
                            <div key={slot} className="group/meal relative p-4 transition-colors hover:bg-cobalt/10">
                              <MealThumb src={meal.img} alt={`Foto de ${meal.name}`} />
                              <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase text-ink/70"><span className="text-ember">🍽️</span>{SLOT_LABEL[slot]}</p>
                              <p className="mt-1.5 pr-8 text-sm font-semibold text-ink/90">{meal.name}</p>
                              <p className="mt-1 text-xs text-ink/75">{meal.desc}</p>
                              <div className="mt-2.5 flex items-center justify-between gap-2">
                                <span className="border border-ink/40 px-1.5 py-0.5 text-[10px] font-bold uppercase text-ink/80">{meal.tag}</span>
                                <div className="flex gap-1">
                                  <button onClick={() => setRecipeMeal(meal)} title="Ver receta" className="grid h-7 w-7 place-items-center border-2 border-ink text-ink transition-all duration-200 hover:bg-ember hover:text-bone active:scale-90">📖</button>
                                  <button onClick={() => swapMeal(dayIdx, slot)} title={`Intercambiar ${SLOT_LABEL[slot].toLowerCase()}`} className="grid h-7 w-7 place-items-center border-2 border-ink text-ink transition-all duration-200 hover:rotate-180 hover:bg-ember hover:text-bone active:scale-90">↻</button>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <div className="flex items-center justify-between gap-3 border-t-2 border-ink px-4 py-3 lg:flex-col lg:justify-center lg:border-t-0 lg:border-l-2 lg:py-6">
                        <span className="text-[10px] font-bold uppercase text-ink/45 lg:rotate-180 lg:[writing-mode:vertical-rl]">Día hecho</span>
                        <button onClick={() => toggleDone(dayIdx)} aria-pressed={done} className={`grid h-11 w-11 place-items-center border-2 transition-all duration-200 active:scale-90 ${done ? "border-ink bg-leaf text-bone shadow-[3px_3px_0_rgba(22,24,29,1)]" : "border-ink bg-bone text-ink/30 hover:bg-mustard hover:text-ink"}`}>✓</button>
                      </div>
                    </div>
                  </article>
                </Reveal>
              );
            })}
          </div>

          {/* Generador */}
          <Reveal delay={0.1}>
            <div className={`mt-10 border-2 border-dashed p-6 text-center transition-colors duration-300 sm:p-10 ${allDone ? "border-ember bg-ember/[0.06]" : "border-ink/30"}`}>
              {allDone ? (
                <>
                  <p className="font-display text-3xl uppercase sm:text-4xl">Semana completa. <span className="text-ember">Toca menú nuevo.</span></p>
                  <p className="mx-auto mt-3 max-w-xl text-sm text-ink/65">El generador reordena los {TOTAL_MENU_OPTIONS} menús intercambiables y te monta la semana {state.week + 2}.</p>
                  <button onClick={generateWeek} className="mt-6 inline-flex items-center gap-3 bg-ember px-8 py-4 font-display text-2xl uppercase text-bone shadow-[6px_6px_0_rgba(22,24,29,1)] transition-all duration-200 hover:translate-x-0.5 hover:translate-y-0.5 hover:bg-ink hover:shadow-[3px_3px_0_rgba(46,107,255,1)] active:translate-x-1 active:translate-y-1 active:shadow-none">↻ Generar nueva semana</button>
                </>
              ) : (
                <>
                  <p className="flex items-center justify-center gap-2 font-display text-2xl uppercase text-ink/45">🔒 Generador bloqueado</p>
                  <p className="mx-auto mt-3 max-w-lg text-sm text-ink/55">Completa los 7 días ({completedCount}/7) para desbloquear el generador de menús intercambiables.</p>
                </>
              )}
              <div className="mt-6 flex items-center justify-center gap-4">
                <button onClick={resetAll} className={`border-2 px-4 py-2 text-xs font-bold uppercase transition-colors ${armedReset ? "border-ember bg-ember text-bone" : "border-ink/30 text-ink/50 hover:border-ink hover:text-ink"}`}>{armedReset ? "¿Seguro? Pulsa otra vez" : "Reiniciar semana"}</button>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* CTA */}
      <section className="relative border-t-2 border-ink bg-mustard py-12">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 px-4 sm:px-6 lg:flex-row lg:items-center">
          <div>
            <p className="text-xs font-bold uppercase text-ink/60">— Plato listo</p>
            <p className="mt-2 font-display text-4xl uppercase sm:text-5xl">Ahora mueve el cuerpo:<br />leve, continuo, <span className="text-ember">sin romperte.</span></p>
          </div>
          <Link to="/" className="group inline-flex shrink-0 items-center gap-3 border-2 border-ink bg-ink px-8 py-4 font-display text-2xl uppercase text-bone transition-colors duration-200 hover:bg-ember hover:border-ember">Ir al entrenamiento →</Link>
        </div>
      </section>

      <footer className="border-t-2 border-ink bg-bone py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 px-4 sm:flex-row sm:items-center sm:px-6">
          <p className="font-display text-lg uppercase">Pizarra<span className="text-ember">·01</span></p>
          <nav className="flex gap-5 text-xs font-bold uppercase">
            <Link to="/" className="text-ink/50 hover:text-ember">Entrenamiento</Link>
            <Link to="/alimentacion" className="text-ink hover:text-ember">Alimentación</Link>
          </nav>
          <p className="text-[11px] text-ink/40">Hábito, no dieta · {new Date().getFullYear()}</p>
        </div>
      </footer>

      <RecipeModal meal={recipeMeal} onClose={() => setRecipeMeal(null)} />
    </div>
  );
}
