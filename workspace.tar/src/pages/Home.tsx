import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import confetti from "canvas-confetti";
import { BLOCKS, MARQUEE_CUES, TOTAL_EXERCISES, TOTAL_MINUTES, type Block, type Exercise } from "../data/routine";
import Marquee from "../components/Marquee";
import Reveal from "../components/Reveal";
import VideoModal from "../components/VideoModal";
import VideoSlot from "../components/VideoSlot";
import { useToast } from "../components/Toast";

const LS_VIDEOS = "pizarra:videos:v1";
const LS_CHECKS = "pizarra:checks:v1";

function loadMap(key: string): Record<string, any> {
  try { return JSON.parse(localStorage.getItem(key) || "{}"); } catch { return {}; }
}

function saveMap(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
}

const ACCENT_CHIP: Record<Block["accent"], string> = { ember: "bg-ember text-bone", cobalt: "bg-cobalt text-bone", mustard: "bg-mustard text-ink" };

function BarbellMark({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M9 12h6" strokeLinecap="square" /><rect x="4.5" y="7" width="3" height="10" /><rect x="16.5" y="7" width="3" height="10" /><path d="M1.5 10v4M22.5 10v4" strokeLinecap="square" />
    </svg>
  );
}

function ForkGlyph({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M7 3v5a2 2 0 0 0 2 2v11M11 3v5M17 3c-1.5 1-2.5 3-2.5 5.5V21M14.5 12h5" strokeLinecap="square" />
    </svg>
  );
}

function CheckGlyph({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2.6"><path d="M4 12.5l5 5L20 6.5" strokeLinecap="square" /></svg>
  );
}

function BlockShell({ block, progressLabel, progressPct, children }: { block: Block; progressLabel: string; progressPct: number; children: React.ReactNode }) {
  const dark = !!block.dark;
  return (
    <section id={block.id} className={`scroll-mt-20 w-full border-t-2 border-ink ${dark ? "bg-blueprint-dark bg-ink text-paper" : "bg-paper text-ink"}`}>
      <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 sm:py-16">
        <Reveal>
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div className="flex items-end gap-3">
              <span className={`font-display text-5xl ${dark ? "text-outline-paper" : "text-outline-ink"}`}>{block.num}</span>
              <div>
                <p className={`mb-2 inline-block px-2 py-0.5 text-xs font-bold uppercase ${ACCENT_CHIP[block.accent]}`}>{block.kicker}</p>
                <h2 className="font-display text-3xl uppercase sm:text-5xl">{block.title}</h2>
              </div>
            </div>
            <div className="w-full max-w-xs">
              <p className={`text-xs ${dark ? "text-paper/55" : "text-ink/55"}`}>{block.focus}</p>
              <div className="mt-2 flex items-center gap-3">
                <span className="border px-2 py-0.5 text-xs font-bold">{block.duration}</span>
                <span className="text-xs font-semibold">{progressLabel}</span>
              </div>
              <div className={`mt-2 h-1.5 w-full ${dark ? "bg-line-dark" : "bg-ink/15"}`}>
                <div className={`h-full transition-all ${dark ? "bg-ember" : "bg-ink"}`} style={{ width: `${progressPct}%` }} />
              </div>
            </div>
          </div>
        </Reveal>
        {children}
      </div>
    </section>
  );
}

export default function Home() {
  const toast = useToast();
  const [videos, setVideos] = useState<Record<string, string | null>>(() => loadMap(LS_VIDEOS));
  const [checks, setChecks] = useState<Record<string, boolean>>(() => loadMap(LS_CHECKS));
  const [timerOn, setTimerOn] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [modal, setModal] = useState<{ ex: Exercise } | null>(null);
  const celebrated = useRef(false);

  useEffect(() => { saveMap(LS_VIDEOS, videos); }, [videos]);
  useEffect(() => { saveMap(LS_CHECKS, checks); }, [checks]);
  useEffect(() => {
    if (!timerOn) return;
    const id = setInterval(() => setElapsed((e) => e + 250), 250);
    return () => clearInterval(id);
  }, [timerOn]);

  const checkedCount = Object.values(checks).filter(Boolean).length;
  const pct = Math.round((checkedCount / TOTAL_EXERCISES) * 100);
  const videosListos = BLOCKS.flatMap((b) => b.exercises).filter((ex) => effectiveVideo(ex)).length;

  useEffect(() => {
    if (checkedCount === TOTAL_EXERCISES && !celebrated.current) {
      celebrated.current = true;
      confetti({ particleCount: 120, spread: 75, origin: { y: 0.7 } });
      toast.push({ kind: "success", title: "Sesión completada", desc: "16/16 movimientos. Nos vemos mañana." });
    }
    if (checkedCount < TOTAL_EXERCISES) celebrated.current = false;
  }, [checkedCount, toast]);

  const effectiveVideo = (ex: Exercise) => ex.id in videos ? videos[ex.id] : ex.defaultVideo || null;
  const setVideo = (exId: string, url: string | null, exName: string) => {
    setVideos((s) => ({ ...s, [exId]: url }));
    if (url) toast.push({ kind: "success", title: `Video colocado en ${exName}`, desc: "Quedó guardado en este dispositivo." });
    else toast.push({ kind: "info", title: `Video quitado de ${exName}`, desc: "El espacio vuelve a quedar libre." });
  };
  const toggleCheck = (ex: Exercise) => setChecks((s) => ({ ...s, [ex.id]: !s[ex.id] }));

  const display = `${String(Math.floor(elapsed / 60000)).padStart(2, "0")}:${String(Math.floor((elapsed % 60000) / 1000)).padStart(2, "0")}`;
  const today = format(new Date(), "EEEE d 'de' MMMM", { locale: es });
  const todayLabel = today.charAt(0).toUpperCase() + today.slice(1);
  const blockProgress = (b: Block) => b.exercises.filter((e) => checks[e.id]).length;

  return (
    <div id="top" className="min-h-screen bg-paper text-ink">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b-2 border-ink bg-paper/95 backdrop-blur-sm">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-2 px-3 py-2 sm:gap-4 sm:px-4 sm:py-3">
          <div className="flex items-center gap-2 cursor-default">
            <span className="grid h-8 w-8 place-items-center bg-ink text-bone sm:h-9 sm:w-9"><BarbellMark /></span>
            <span className="font-display text-base tracking-wide uppercase sm:text-xl">Pizarra</span>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/alimentacion" className="flex items-center gap-1 bg-ember px-2 py-1.5 text-[10px] font-bold tracking-[0.14em] text-bone uppercase transition-colors hover:bg-ink sm:gap-1.5 sm:px-3 sm:py-2 sm:text-[11px]">
              <ForkGlyph className="h-3 w-3 sm:h-3.5 sm:w-3.5" /><span>Alimentación</span>
            </Link>
            <span className="tabular text-[11px] font-bold sm:text-xs">{checkedCount}/{TOTAL_EXERCISES}</span>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-blueprint relative overflow-hidden">
        <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-16">
          <Reveal>
            <div className="flex flex-wrap items-center gap-2 text-[11px] font-bold uppercase">
              <span className="bg-ember px-2.5 py-1 text-bone">Semana 12 · Día 3</span>
              <span className="border border-ink px-2.5 py-1">{todayLabel}</span>
            </div>
            <h1 className="font-display mt-6 text-[13vw] leading-[0.88] uppercase sm:text-7xl">Rutina<br /><span className="text-outline-ink">de hoy</span></h1>
            <p className="mt-6 max-w-md text-base text-ink/70">Cuatro bloques con videos tutoriales y descripciones paso a paso para cada ejercicio.</p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-8 grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4">
              {[{ v: `${TOTAL_MINUTES}′`, l: "duración total" }, { v: "4", l: "bloques" }, { v: String(TOTAL_EXERCISES), l: "movimientos" }, { v: String(videosListos), l: "videos listos" }].map((s) => (
                <div key={s.l} className="border-l-2 border-ember pl-3">
                  <p className="font-display text-3xl">{s.v}</p>
                  <p className="text-[11px] font-semibold uppercase text-ink/50">{s.l}</p>
                </div>
              ))}
            </div>
          </Reveal>
          {/* Cronómetro */}
          <Reveal delay={0.2}>
            <div className="mt-8 border-2 border-ink bg-ink p-6 text-paper shadow-[10px_10px_0_var(--color-ember)]">
              <p className="text-xs font-bold uppercase text-paper/60">Cronómetro de sesión</p>
              <p className="font-display tabular mt-4 text-5xl sm:text-7xl">{display}</p>
              <div className="mt-4 flex gap-2">
                <button onClick={() => setTimerOn(!timerOn)} className={`flex-1 px-4 py-3 font-display text-lg uppercase ${timerOn ? "bg-mustard text-ink" : "bg-ember text-bone"}`}>{timerOn ? "Pausar" : "Iniciar"}</button>
                <button onClick={() => { setElapsed(0); setTimerOn(false); }} className="border-2 border-paper/30 px-4 py-3 text-sm font-bold uppercase">00:00</button>
              </div>
              <div className="mt-4 border-t border-paper/15 pt-4">
                <div className="flex justify-between text-xs">
                  <span className="uppercase text-paper/55">Completado</span>
                  <span className="tabular font-bold">{checkedCount}/{TOTAL_EXERCISES} · {pct}%</span>
                </div>
                <div className="mt-2 h-2 bg-line-dark"><div className="h-full bg-ember transition-all" style={{ width: `${pct}%` }} /></div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <Marquee items={MARQUEE_CUES} />

      {/* La base es el plato */}
      <section className="w-full border-b-2 border-ink bg-mustard">
        <Link to="/alimentacion" className="group mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-x-4 gap-y-3 px-4 py-4 sm:gap-x-8 sm:px-6 sm:py-5">
          <span className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center bg-ink text-mustard transition-transform duration-300 group-hover:-rotate-6 sm:h-11 sm:w-11"><ForkGlyph className="h-4 w-4 sm:h-5 sm:w-5" /></span>
            <span>
              <span className="font-display block text-xl uppercase sm:text-3xl">La base es el plato</span>
              <span className="mt-1 block text-[10px] font-semibold uppercase text-ink/60 sm:text-[11px]">Plan de 7 días · menús intercambiables · sin hacer dieta</span>
            </span>
          </span>
          <span className="flex items-center gap-2 bg-ink px-3 py-2 text-xs font-bold uppercase text-mustard transition-colors group-hover:bg-ember group-hover:text-bone sm:px-4 sm:py-2.5 sm:text-sm">Ver el plan →</span>
        </Link>
      </section>

      {/* Bloques */}
      {BLOCKS.map((block) => {
        const done = blockProgress(block);
        return (
          <BlockShell key={block.id} block={block} progressLabel={`${done}/${block.exercises.length}`} progressPct={(done / block.exercises.length) * 100}>
            {block.note && <Reveal><p className="mb-8 max-w-2xl border-l-2 border-ember pl-4 text-sm text-paper/70">{block.note}</p></Reveal>}
            <div className="grid gap-6 xl:grid-cols-2">
              {block.exercises.map((ex, i) => (
                <Reveal key={ex.id} delay={(i % 2) * 0.1}>
                  <article className={`flex h-full flex-col border-2 p-4 ${block.dark ? "border-line-dark bg-ink-2" : "border-ink bg-bone"}`}>
                    <VideoSlot exercise={ex} video={effectiveVideo(ex)} onAdd={() => setModal({ ex })} onRemove={() => setVideo(ex.id, null, ex.name)} />
                    <h3 className="font-display mt-4 text-xl uppercase">{ex.name}</h3>
                    <div className="mt-2 flex flex-wrap gap-2 text-xs">
                      <span className={`px-2 py-0.5 font-bold ${block.dark ? "bg-mustard text-ink" : "bg-ink text-bone"}`}>{ex.scheme}</span>
                      {ex.rest && ex.rest !== "—" && <span className="border px-2 py-0.5 font-semibold">descanso {ex.rest}</span>}
                    </div>
                    {ex.cues && (
                      <ul className="mt-4 space-y-2">
                        {ex.cues.map((cue) => (
                          <li key={cue} className="flex items-start gap-2 text-sm"><span className="text-ember mt-0.5">▸</span><span>{cue}</span></li>
                        ))}
                      </ul>
                    )}
                    <button onClick={() => toggleCheck(ex)} className={`mt-auto pt-4 text-left text-sm font-semibold uppercase ${checks[ex.id] ? "text-leaf" : "opacity-50 hover:opacity-100"}`}>
                      {checks[ex.id] ? "✓ Completado" : "Marcar como hecho →"}
                    </button>
                  </article>
                </Reveal>
              ))}
            </div>
          </BlockShell>
        );
      })}

      {/* Footer */}
      <footer className="w-full border-t-2 border-ink bg-ink text-paper">
        <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6">
          <p className="font-display text-4xl uppercase sm:text-6xl">Nos vemos<br /><span className="text-outline-paper">mañana.</span></p>
          <div className="mt-8 flex flex-wrap gap-4">
            <button onClick={() => { setChecks({}); setElapsed(0); setTimerOn(false); toast.push({ kind: "info", title: "Sesión reiniciada" }); }} className="border-2 border-paper/30 px-5 py-3 text-sm font-bold uppercase hover:bg-ember">Reiniciar sesión</button>
            <Link to="/alimentacion" className="flex items-center gap-1.5 text-xs font-semibold uppercase text-paper/50 hover:text-ember"><ForkGlyph className="h-3.5 w-3.5" />Plan de alimentación</Link>
          </div>
        </div>
      </footer>

      <VideoModal open={modal !== null} exerciseName={modal?.ex.name ?? ""} initial={(modal && effectiveVideo(modal.ex)) || ""}
        onSave={(url) => { if (modal) setVideo(modal.ex.id, url, modal.ex.name); setModal(null); }} onClose={() => setModal(null)} />
    </div>
  );
}
